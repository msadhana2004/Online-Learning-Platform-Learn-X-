
package com.learnx.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import com.learnx.repository.*;
import com.learnx.model.*;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin
public class AdminController {

 @Autowired
 UserRepository userRepo;

 @Autowired
 CourseRepository courseRepo;

 @Autowired
 PaymentRepository paymentRepo;

 @GetMapping("/users")
 public List<User> users(){
  return userRepo.findAll();
 }

 @GetMapping("/payments")
 public List<Payment> payments(){
  return paymentRepo.findAll();
 }

 @DeleteMapping("/course/{id}")
 public void deleteCourse(@PathVariable Long id){
  courseRepo.deleteById(id);
 }
}
