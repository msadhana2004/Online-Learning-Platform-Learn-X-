package com.learnx.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import com.learnx.model.Enrollment;
import com.learnx.repository.EnrollmentRepository;

@RestController
@RequestMapping("/api/enroll")
@CrossOrigin
public class EnrollmentController {

    @Autowired
    private EnrollmentRepository enrollmentRepo;

    // Enroll course
    @PostMapping
    public Enrollment enroll(@RequestBody Enrollment enrollment) {
        return enrollmentRepo.save(enrollment);
    }

    // Get all enrollments
    @GetMapping
    public List<Enrollment> getAllEnrollments() {
        return enrollmentRepo.findAll();
    }

    // Get enrollment by ID
    @GetMapping("/{id}")
    public Enrollment getEnrollmentById(@PathVariable Long id) {
        return enrollmentRepo.findById(id).orElse(null);
    }

    // Get enrollments by user
    @GetMapping("/user/{userId}")
    public List<Enrollment> getUserEnrollments(@PathVariable Long userId) {
        return enrollmentRepo.findByUserId(userId);
    }
}