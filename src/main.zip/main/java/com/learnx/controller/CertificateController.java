package com.learnx.controller;

import com.learnx.model.Certificate;
import com.learnx.model.User;
import com.learnx.model.Course;
import com.learnx.repository.CertificateRepository;
import com.learnx.repository.UserRepository;
import com.learnx.repository.CourseRepository;

import com.openhtmltopdf.pdfboxout.PdfRendererBuilder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.io.ByteArrayOutputStream;
import java.time.LocalDate;
import java.util.Map;

@RestController
@RequestMapping("/api/certificate")
public class CertificateController {

    @Autowired
    private CertificateRepository certificateRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CourseRepository courseRepository;

    @PostMapping("/generate")
    public ResponseEntity<byte[]> generateCertificatePdf(@RequestBody Map<String, Long> request) {

        Long userId = request.get("userId");
        Long courseId = request.get("courseId");

        // Debug log
        System.out.println("Generating certificate for userId=" + userId + ", courseId=" + courseId);

        // Fetch user & course safely
        User user = userRepository.findById(userId).orElse(null);
        if (user == null) {
            System.out.println("User not found: " + userId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }

        Course course = courseRepository.findById(courseId).orElse(null);
        if (course == null) {
            System.out.println("Course not found: " + courseId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }

        // Save certificate record
        Certificate cert = new Certificate();
        cert.setUserId(userId);
        cert.setCourseId(courseId);
        String certCode = "CERT-" + System.currentTimeMillis();
        cert.setCertificateUrl(certCode); // store code
        certificateRepository.save(cert);

        // Create PDF content dynamically
        String html = "<div style='text-align:center; padding:50px; border:5px solid black;'>"
                + "<h1>Certificate of Completion</h1>"
                + "<h2>" + user.getName() + "</h2>"
                + "<p>has successfully completed the course</p>"
                + "<h3>" + course.getTitle() + "</h3>"
                + "<p>on " + LocalDate.now() + "</p>"
                + "<p>Certificate ID: " + certCode + "</p>"
                + "</div>";

        byte[] pdfBytes;

        // Convert HTML -> PDF with error handling
        try {
            ByteArrayOutputStream os = new ByteArrayOutputStream();
            PdfRendererBuilder builder = new PdfRendererBuilder();
            builder.withHtmlContent(html, null);
            builder.toStream(os);
            builder.run();
            pdfBytes = os.toByteArray();
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }

        // Return PDF with proper headers
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_PDF);
        headers.setContentDisposition(
                ContentDisposition.builder("attachment")
                        .filename("certificate.pdf")
                        .build()
        );

        return new ResponseEntity<>(pdfBytes, headers, HttpStatus.OK);
    }
}