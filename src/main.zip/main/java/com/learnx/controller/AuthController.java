package com.learnx.controller;

import com.learnx.model.User;
import com.learnx.repository.UserRepository;
import com.learnx.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin
public class AuthController {

    @Autowired
    private UserRepository repo;

    @Autowired
    private JwtUtil jwtUtil;

    // ================= Register =================
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody User user){

        if(repo.findByEmail(user.getEmail()) != null){
            return ResponseEntity.badRequest().body("Email already registered");
        }

        user.setRole("USER");

        User savedUser = repo.save(user);
        savedUser.setPassword(null);

        return ResponseEntity.ok(savedUser);
    }

    // ================= Login =================
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User user){

        User existing = repo.findByEmail(user.getEmail());

        if(existing == null){
            return ResponseEntity.status(401).body("User not found");
        }

        if(!existing.getPassword().equals(user.getPassword())){
            return ResponseEntity.status(401).body("Invalid password");
        }

        // Generate JWT
        String token = jwtUtil.generateToken(existing.getEmail());

        Map<String, String> response = new HashMap<>();
        response.put("token", token);

        return ResponseEntity.ok(response);
    }
}