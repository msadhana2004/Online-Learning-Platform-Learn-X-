package com.learnx.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import com.learnx.model.Payment;
import com.learnx.repository.PaymentRepository;

@RestController
@RequestMapping("/api/payments")
@CrossOrigin
public class PaymentController {

 @Autowired
 private PaymentRepository paymentRepo;

 @PostMapping
 public Payment makePayment(@RequestBody Payment payment){
  return paymentRepo.save(payment);
 }

 @GetMapping
 public List<Payment> getPayments(){
  return paymentRepo.findAll();
 }
}