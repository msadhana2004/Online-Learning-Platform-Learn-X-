package com.learnx.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

import com.learnx.model.Course;
import com.learnx.repository.CourseRepository;

@RestController
@RequestMapping("/api/courses")
@CrossOrigin
public class CourseController {

 @Autowired
 private CourseRepository repo;

 @GetMapping
 public List<Course> getCourses(){
  return repo.findAll();
 }

 @PostMapping
 public Course addCourse(@RequestBody Course course){
  return repo.save(course);
 }
}