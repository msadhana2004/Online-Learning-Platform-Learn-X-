package com.learnx.model;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Course {

 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Long id;

 private String title;
 private String instructor;
 private String category;
 private double price;

 private String video;
 private String image;

 private String about;
 private String level;
 private String duration;
 private String language;

 private double rating;
 private int reviews;
 private String enrolled;

 @ElementCollection
 private List<String> skills;

 @ElementCollection
 private List<String> tools;

 public Long getId() { return id; }
 public void setId(Long id) { this.id = id; }

 public String getTitle() { return title; }
 public void setTitle(String title) { this.title = title; }

 public String getInstructor() { return instructor; }
 public void setInstructor(String instructor) { this.instructor = instructor; }

 public String getCategory() { return category; }
 public void setCategory(String category) { this.category = category; }

 public double getPrice() { return price; }
 public void setPrice(double price) { this.price = price; }

 public String getVideo() { return video; }
 public void setVideo(String video) { this.video = video; }

 public String getImage() { return image; }
 public void setImage(String image) { this.image = image; }

 public String getAbout() { return about; }
 public void setAbout(String about) { this.about = about; }

 public String getLevel() { return level; }
 public void setLevel(String level) { this.level = level; }

 public String getDuration() { return duration; }
 public void setDuration(String duration) { this.duration = duration; }

 public String getLanguage() { return language; }
 public void setLanguage(String language) { this.language = language; }

 public double getRating() { return rating; }
 public void setRating(double rating) { this.rating = rating; }

 public int getReviews() { return reviews; }
 public void setReviews(int reviews) { this.reviews = reviews; }

 public String getEnrolled() { return enrolled; }
 public void setEnrolled(String enrolled) { this.enrolled = enrolled; }

 public List<String> getSkills() { return skills; }
 public void setSkills(List<String> skills) { this.skills = skills; }

 public List<String> getTools() { return tools; }
 public void setTools(List<String> tools) { this.tools = tools; }
}