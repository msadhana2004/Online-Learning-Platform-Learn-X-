import { useParams, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import Navbar from "../Components/Navbar";
import Footer from "../Components/Footer";

function Payment() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [method, setMethod] = useState("UPI");

  const [course, setCourse] = useState(null);
  const [loading, setLoading] = useState(true);

  const userEmail = "user@gmail.com"; // Replace with real user data
  const userId = 1; // Replace with real user ID

  // Fetch course from backend
  useEffect(() => {
    const fetchCourse = async () => {
      const token = localStorage.getItem("token"); // JWT token
      try {
        const response = await fetch(`http://localhost:8080/api/courses/${id}`, {
          headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + token,
          },
        });

        if (!response.ok) throw new Error("Course not found");

        const data = await response.json();
        setCourse(data);
      } catch (error) {
        console.error(error);
        setCourse(null);
      } finally {
        setLoading(false);
      }
    };

    fetchCourse();
  }, [id]);

  // Handle payment
  const handlePayment = async () => {
    if (!course) return;

    const token = localStorage.getItem("token"); // JWT token

    if (method === "UPI") {
      try {
        const res = await fetch("http://localhost:8080/api/enroll", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + token, // ✅ Include JWT token
          },
          body: JSON.stringify({
            userId: userId,
            courseId: course.id,
            status: "PAID",
          }),
        });

        if (!res.ok) throw new Error("Enrollment failed");

        navigate(`/payment-success/${course.id}`, {
          state: {
            course: course,
            total: course.price - Math.round(course.price * 0.4) + Math.round((course.price - Math.round(course.price * 0.4)) * 0.18),
          },
        });
      } catch (error) {
        console.error(error);
        alert("Payment failed. Try again.");
      }
    } else if (method === "Card") {
      alert("Card payment demo not implemented yet");
    }
  };

  if (loading) {
    return (
      <>
        <Navbar />
        <div className="min-h-screen flex justify-center items-center">
          <h1 className="text-2xl text-gray-600">Loading Course...</h1>
        </div>
        <Footer />
      </>
    );
  }

  if (!course) {
    return (
      <>
        <Navbar />
        <div className="min-h-screen flex justify-center items-center">
          <h1 className="text-2xl font-bold text-red-600">Course Not Found</h1>
        </div>
        <Footer />
      </>
    );
  }

  const discount = Math.round(course.price * 0.4);
  const discountedFee = course.price - discount;
  const gst = Math.round(discountedFee * 0.18);
  const total = discountedFee + gst;

  return (
    <>
      <Navbar />
      <section className="bg-gray-100 min-h-screen flex justify-center items-center py-20 px-6">
        <div className="bg-white shadow-lg rounded-lg w-full max-w-md p-8">
          <div className="text-center mb-6">
            <h1 className="text-blue-600 font-bold text-2xl">LearnX</h1>
          </div>

          <div className="bg-gray-100 rounded-md p-3 text-sm mb-6">
            You are making payment for
            <p className="font-semibold">{userEmail}</p>
          </div>

          <h2 className="font-semibold text-lg mb-2">{course.title}</h2>

          <p className="text-sm text-gray-600 mb-4">
            Access 500+ courses • 500+ coding exercises • 50+ projects •
            Unlimited mock interviews
          </p>

          <p className="text-sm text-gray-500 mb-6">Renew monthly • Cancel anytime</p>

          <h3 className="font-semibold mb-3">Bill details</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between"><span>Subscription fee</span><span>₹{course.price}</span></div>
            <div className="flex justify-between text-green-600"><span>Your Discount</span><span>-₹{discount}</span></div>
            <div className="flex justify-between font-semibold"><span>Discounted fee</span><span>₹{discountedFee}</span></div>
            <div className="flex justify-between"><span>GST (18%)</span><span>₹{gst}</span></div>
            <hr />
            <div className="flex justify-between font-bold text-blue-600 text-lg"><span>Total</span><span>₹{total}</span></div>
          </div>

          <h3 className="font-semibold mt-6 mb-3">Mode of payment</h3>
          <div className="flex gap-6 mb-6">
            <label className="flex items-center gap-2">
              <input type="radio" value="UPI" checked={method === "UPI"} onChange={(e) => setMethod(e.target.value)} /> UPI
            </label>
            <label className="flex items-center gap-2">
              <input type="radio" value="Card" checked={method === "Card"} onChange={(e) => setMethod(e.target.value)} /> Card
            </label>
          </div>

          <button onClick={handlePayment} className="bg-blue-600 hover:bg-blue-700 text-white w-full py-3 rounded-md font-semibold transition">
            Pay ₹{total}
          </button>
          <p className="text-center text-xs text-gray-500 mt-4">🔒 Secured connection</p>
        </div>
      </section>
      <Footer />
    </>
  );
}

export default Payment;