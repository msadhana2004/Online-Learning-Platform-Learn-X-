import { useParams, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import Navbar from "../Components/Navbar";
import Footer from "../Components/Footer";

function CourseDetails() {

  const { id } = useParams();
  const navigate = useNavigate();

  const [course, setCourse] = useState(null);
  const [activeIndex, setActiveIndex] = useState(null);

  useEffect(() => {


    fetch(`http://localhost:8080/api/courses/${id}`)
      .then(res => res.json())
      .then(data => setCourse(data))
      .catch(err => console.log(err));


  }, [id]);

  const toggleModule = (index) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  const handleBuy = async () => {


    const token = localStorage.getItem("token");
    const userId = localStorage.getItem("userId");

    if (!token) {
      alert("Please login first");
      navigate("/login", { state: { from: `/courses/${id}` } });
      return;
    }

    try {

      // FREE COURSE
      if (course.price === 0) {

        const res = await fetch("http://localhost:8080/api/enroll", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + token
          },
          body: JSON.stringify({
            userId: Number(userId),
            courseId: Number(id),
            status: "ENROLLED"
          })
        });

        if (res.ok) {
          alert("Enrollment Successful 🎉");
          navigate("/my-courses");
        } else {
          alert("Enrollment Failed");
        }

      }

      // PAID COURSE
      else {

        navigate(`/payment/${course.id}`, {
          state: { course, total: course.price }
        });

      }

    } catch (error) {
      console.log(error);
      alert("Server error");
    }


  };

  if (!course) {
    return (
      <> <Navbar /> <h1 className="text-center mt-20 text-2xl font-bold">
        Loading Course... </h1> <Footer />
      </>
    );
  }

  return (
    <> <Navbar />


      < section className="bg-[#F8FAFC] min-h-screen" >

        <div className="bg-[#1E3A8A] text-white py-16 px-6 md:px-20">

          <h1 className="text-4xl font-bold mb-4">
            {course.title}
          </h1>

          <p className="mb-4">
            Instructor: <span className="font-semibold">{course.instructor}</span>
          </p>

          {course.rating && (
            <p className="mb-2">
              ⭐ {course.rating} ({course.reviews} reviews)
            </p>
          )}

          <button
            onClick={handleBuy}
            className="bg-[#F97316] px-6 py-3 rounded-lg font-semibold"
          >
            {course.price === 0 ? "Enroll Now" : `Buy Now ₹${course.price}`}
          </button>

        </div>

        <div className="py-16 px-6 md:px-20">

          {course.about && (
            <>
              <h2 className="text-2xl font-bold mb-4">
                About this Course
              </h2>

              <p className="text-gray-700 mb-10">
                {course.about}
              </p>
            </>
          )}

          {course.outline && course.outline.length > 0 && (
            <>
              <h2 className="text-2xl font-bold mb-6">
                Course Outline
              </h2>

              <div className="space-y-4 mb-12">

                {course.outline.map((module, index) => (

                  <div key={module.id} className="bg-white shadow-md rounded-lg overflow-hidden">

                    <button
                      onClick={() => toggleModule(index)}
                      className="w-full text-left p-5 flex justify-between items-center hover:bg-gray-50"
                    >

                      <span className="font-semibold text-gray-800">
                        📘 {module.title}
                      </span>

                      <span className="text-blue-600 font-bold text-xl">
                        {activeIndex === index ? "-" : "+"}
                      </span>

                    </button>

                    {activeIndex === index && (
                      <div className="px-5 pb-5 text-gray-600 border-t">
                        {module.description}
                      </div>
                    )}

                  </div>

                ))}

              </div>
            </>
          )}

          {course.skills && course.skills.length > 0 && (
            <>
              <h2 className="text-2xl font-bold mb-4">
                Skills You'll Gain
              </h2>

              <div className="grid md:grid-cols-3 gap-4 mb-10">

                {course.skills.map((skill, index) => (
                  <div key={index} className="bg-white shadow-md p-4 rounded-lg text-center">
                    {skill}
                  </div>
                ))}

              </div>
            </>
          )}

          {course.tools && course.tools.length > 0 && (
            <>
              <h2 className="text-2xl font-bold mb-4">
                Tools You'll Learn
              </h2>

              <div className="flex flex-wrap gap-4 mb-10">

                {course.tools.map((tool, index) => (
                  <span
                    key={index}
                    className="bg-blue-100 text-blue-700 px-4 py-2 rounded-full text-sm"
                  >
                    {tool}
                  </span>
                ))}

              </div>
            </>
          )}

        </div>

      </section >

      <Footer />
    </>


  );
}

export default CourseDetails;
