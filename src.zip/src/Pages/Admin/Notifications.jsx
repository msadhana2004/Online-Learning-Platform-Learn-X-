import { useState, useEffect } from "react";
import AdminLayout from "./AdminLayout";

function Notifications() {

    const [message, setMessage] = useState("");
    const [notifications, setNotifications] = useState([]);

    useEffect(() => {

        fetch("http://localhost:8080/api/admin/notifications")
            .then(res => res.json())
            .then(data => setNotifications(data));

    }, []);

    const sendNotification = async (e) => {

        e.preventDefault();

        if (!message.trim()) return;

        const res = await fetch("http://localhost:8080/api/admin/notification", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                message: message
            })
        });

        const data = await res.json();

        setNotifications([data, ...notifications]);

        setMessage("");

    };

    return (

        <AdminLayout>

            <div className="flex flex-col space-y-8">

                <h1 className="text-3xl font-bold">Notifications / Announcements</h1>

                <form
                    onSubmit={sendNotification}
                    className="bg-white shadow rounded-lg p-6 max-w-xl"
                >

                    <textarea
                        placeholder="Enter announcement..."
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        className="w-full border p-3 rounded mb-3"
                        rows={4}
                    />

                    <button
                        type="submit"
                        className="bg-blue-600 text-white px-5 py-2 rounded"
                    >
                        Send Notification
                    </button>

                </form>

                <div className="bg-white shadow rounded-lg p-6">

                    <h2 className="text-xl font-semibold mb-4">Sent Notifications</h2>

                    {notifications.length === 0 ? (

                        <p>No notifications sent yet.</p>

                    ) : (

                        <ul>

                            {notifications.map((note) => (

                                <li key={note.id} className="border-b py-2">

                                    {note.message}

                                </li>

                            ))}

                        </ul>

                    )}

                </div>

            </div>

        </AdminLayout>

    );
}

export default Notifications;