import React, { useState } from "react";
import AdminLayout from "./AdminLayout";
import Modal from "../../Components/Modal"; // optional, for delete/edit confirmation

function ManageCourses() {
    const [modalOpen, setModalOpen] = useState(false);
    const [selectedCourse, setSelectedCourse] = useState(null);

    const courses = [
        { title: "React for Beginners", instructor: "John David", price: "Paid", category: "Web Dev" },
        { title: "Python Basics", instructor: "Priya Sharma", price: "Free", category: "Programming" },
    ];

    const handleDelete = (course) => {
        setSelectedCourse(course);
        setModalOpen(true);
    };

    return (
        <AdminLayout>
            <h1 className="text-2xl font-bold mb-6">Manage Courses</h1>

            <div className="overflow-x-auto bg-white rounded shadow">
                <table className="min-w-full">
                    <thead>
                        <tr className="bg-gray-100">
                            <th className="px-4 py-2">Title</th>
                            <th className="px-4 py-2">Instructor</th>
                            <th className="px-4 py-2">Price</th>
                            <th className="px-4 py-2">Category</th>
                            <th className="px-4 py-2">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {courses.map((c, idx) => (
                            <tr key={idx} className="border-t hover:bg-gray-50 transition-colors">
                                <td className="px-4 py-2">{c.title}</td>
                                <td className="px-4 py-2">{c.instructor}</td>
                                <td className="px-4 py-2">{c.price}</td>
                                <td className="px-4 py-2">{c.category}</td>
                                <td className="px-4 py-2">
                                    <button className="bg-green-500 text-white px-3 py-1 rounded mr-2 hover:bg-green-600">
                                        Edit
                                    </button>
                                    <button
                                        className="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600"
                                        onClick={() => handleDelete(c)}
                                    >
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* Modal for Delete Confirmation */}
            {modalOpen && (
                <Modal open={modalOpen} setOpen={setModalOpen}>
                    <h2 className="text-lg font-bold">Delete Course</h2>
                    <p className="mt-2">Are you sure you want to delete "{selectedCourse?.title}"?</p>
                    <div className="mt-4 flex justify-end space-x-2">
                        <button className="btn-primary" onClick={() => setModalOpen(false)}>
                            Cancel
                        </button>
                        <button
                            className="bg-red-600 text-white px-4 py-2 rounded"
                            onClick={() => {
                                // delete logic here
                                setModalOpen(false);
                            }}
                        >
                            Delete
                        </button>
                    </div>
                </Modal>
            )}
        </AdminLayout>
    );
}

export default ManageCourses;