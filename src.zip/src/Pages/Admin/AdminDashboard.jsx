import React, { useState, useEffect } from "react";
import AdminLayout from "./AdminLayout";
import StatsCard from "../../Components/StatsCard";
import { UserIcon, CurrencyRupeeIcon } from "@heroicons/react/24/outline";
import AddCourse from "./AddCourse";

function AdminDashboard() {
    const [courses, setCourses] = useState([]);

    useEffect(() => {
        fetch("http://localhost:8080/api/courses")
            .then(res => res.json())
            .then(data => setCourses(data))
            .catch(err => console.error("Fetch courses error:", err));
    }, []);

    const handleCourseAdded = (newCourse) => setCourses([...courses, newCourse]);

    return (
        <AdminLayout>
            <h1 className="text-2xl font-bold mb-6">Admin Dashboard</h1>

            <div className="grid md:grid-cols-4 gap-6 mb-6">
                <StatsCard title="Total Users" value="120" icon={<UserIcon className="w-6 h-6 text-blue-600" />} />
                <StatsCard title="Total Courses" value={courses.length} icon="📚" />
                <StatsCard title="Revenue" value="₹1,50,000" icon={<CurrencyRupeeIcon className="w-6 h-6 text-green-600" />} />
                <StatsCard title="New Enrollments" value="45" icon="📝" />
            </div>

            <AddCourse onCourseAdded={handleCourseAdded} />

            <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div className="bg-white p-4 rounded shadow">
                    <h2 className="text-lg font-bold mb-4">Free Courses</h2>
                    <ul>
                        {courses.filter(c => c.price === 0).map(c => <li key={c.id}>{c.title} - {c.instructor}</li>)}
                    </ul>
                </div>
                <div className="bg-white p-4 rounded shadow">
                    <h2 className="text-lg font-bold mb-4">Paid Courses</h2>
                    <ul>
                        {courses.filter(c => c.price > 0).map(c => <li key={c.id}>{c.title} - {c.instructor}</li>)}
                    </ul>
                </div>
            </div>
        </AdminLayout>
    );
}

export default AdminDashboard;