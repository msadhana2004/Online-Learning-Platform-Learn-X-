import { useState, useEffect } from "react";
import AdminLayout from "./AdminLayout";

function ManageUsers() {

  const [users, setUsers] = useState([]);

  // Fetch users from backend
  useEffect(() => {

    fetch("http://localhost:8080/api/admin/users")
      .then(res => res.json())
      .then(data => setUsers(data))
      .catch(err => console.log(err));

  }, []);

  // Toggle user status
  const toggleStatus = (userId) => {

    const updatedUsers = users.map((user) =>
      user.id === userId
        ? {
            ...user,
            status: user.status === "Active" ? "Blocked" : "Active"
          }
        : user
    );

    setUsers(updatedUsers);
  };

  return (
    <AdminLayout>

      <div className="flex flex-col space-y-8">

        <h1 className="text-3xl font-bold">Manage Users</h1>

        <div className="bg-white shadow rounded-lg overflow-x-auto">

          <table className="w-full text-left">

            <thead className="bg-gray-200">
              <tr>
                <th className="p-4">Name</th>
                <th className="p-4">Email</th>
                <th className="p-4">Status</th>
                <th className="p-4">Action</th>
              </tr>
            </thead>

            <tbody>

              {users.length === 0 ? (
                <tr>
                  <td className="p-4" colSpan="4">
                    No users found
                  </td>
                </tr>
              ) : (
                users.map((user) => (

                  <tr key={user.id} className="border-b hover:bg-gray-50">

                    <td className="p-4">{user.name}</td>

                    <td className="p-4">{user.email}</td>

                    <td className="p-4">
                      <span
                        className={`font-semibold ${
                          user.status === "Blocked"
                            ? "text-red-600"
                            : "text-green-600"
                        }`}
                      >
                        {user.status || "Active"}
                      </span>
                    </td>

                    <td className="p-4">

                      <button
                        onClick={() => toggleStatus(user.id)}
                        className="bg-blue-600 text-white px-4 py-1 rounded hover:bg-blue-700"
                      >
                        {user.status === "Blocked" ? "Unblock" : "Block"}
                      </button>

                    </td>

                  </tr>

                ))
              )}

            </tbody>

          </table>

        </div>

      </div>

    </AdminLayout>
  );
}

export default ManageUsers;