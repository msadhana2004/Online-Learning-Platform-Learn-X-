import React, { useState } from "react";

function AddCourse() {
  const [course, setCourse] = useState({
    title: "",
    instructor: "",
    category: "",
    price: 0,
    video: "",
    image: "",
    about: "",
    level: "",
    duration: "",
    language: "",
    rating: 0,
    reviews: 0,
    enrolled: 0,
    skills: [],
    tools: [],
  });

  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name === "skills" || name === "tools") {
      setCourse({ ...course, [name]: value.split(",").map(s => s.trim()) });
    } else if (name === "price" || name === "rating") {
      setCourse({ ...course, [name]: parseFloat(value) });
    } else if (name === "reviews" || name === "enrolled") {
      setCourse({ ...course, [name]: parseInt(value) });
    } else {
      setCourse({ ...course, [name]: value });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const token = localStorage.getItem("token");

    if (!token) return alert("Login as admin first");

    try {
      const response = await fetch("http://localhost:8080/api/admin/courses", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`,
        },
        body: JSON.stringify(course),
      });

      if (!response.ok) throw new Error(await response.text());

      const data = await response.json();
      alert("Course added successfully!");
      console.log(data);

      // Reset form
      setCourse({
        title: "",
        instructor: "",
        category: "",
        price: 0,
        video: "",
        image: "",
        about: "",
        level: "",
        duration: "",
        language: "",
        rating: 0,
        reviews: 0,
        enrolled: 0,
        skills: [],
        tools: [],
      });

    } catch (error) {
      console.error(error);
      alert("Failed to add course. Check console.");
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="title" placeholder="Title" value={course.title} onChange={handleChange} />
      <input name="instructor" placeholder="Instructor" value={course.instructor} onChange={handleChange} />
      <input name="category" placeholder="Category" value={course.category} onChange={handleChange} />
      <input name="price" type="number" placeholder="Price" value={course.price} onChange={handleChange} />
      <input name="video" placeholder="Video URL" value={course.video} onChange={handleChange} />
      <input name="image" placeholder="Image URL" value={course.image} onChange={handleChange} />
      <input name="level" placeholder="Level" value={course.level} onChange={handleChange} />
      <input name="duration" placeholder="Duration" value={course.duration} onChange={handleChange} />
      <input name="language" placeholder="Language" value={course.language} onChange={handleChange} />
      <input name="rating" type="number" step="0.1" placeholder="Rating" value={course.rating} onChange={handleChange} />
      <input name="reviews" type="number" placeholder="Reviews" value={course.reviews} onChange={handleChange} />
      <input name="enrolled" type="number" placeholder="Enrolled" value={course.enrolled} onChange={handleChange} />
      <input name="skills" placeholder="Skills (comma separated)" onChange={handleChange} />
      <input name="tools" placeholder="Tools (comma separated)" onChange={handleChange} />
      <textarea name="about" placeholder="About" value={course.about} onChange={handleChange}></textarea>
      <button type="submit">Add Course</button>
    </form>
  );
}

export default AddCourse;