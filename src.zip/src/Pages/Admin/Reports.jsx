import { useEffect, useState } from "react";
import AdminLayout from "./AdminLayout";
import RevenueChart from "../../Components/RevenueChart";

function Reports() {

  const [stats, setStats] = useState({
    totalUsers: 0,
    totalCourses: 0,
    totalPayments: 0
  });

  useEffect(() => {
    const token = localStorage.getItem("token"); // JWT token fetch

    if (!token) {
      console.log("Admin token not found. Login required.");
      return;
    }

    fetch("http://localhost:8080/api/admin/reports", {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`  // ✅ Attach JWT
      }
    })
      .then(res => {
        if (!res.ok) {
          throw new Error(`HTTP error! Status: ${res.status}`);
        }
        return res.json();
      })
      .then(data => setStats(data))
      .catch(err => console.error("Error fetching reports:", err));

  }, []);

  return (
    <AdminLayout>
      <div className="flex flex-col space-y-8">
        <h1 className="text-3xl font-bold">Reports & Analytics</h1>

        <div className="grid md:grid-cols-4 gap-6">
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-lg font-semibold">Total Users</h2>
            <p className="text-3xl font-bold mt-2">{stats.totalUsers}</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-lg font-semibold">Total Courses</h2>
            <p className="text-3xl font-bold mt-2">{stats.totalCourses}</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-lg font-semibold">Total Payments</h2>
            <p className="text-3xl font-bold mt-2">{stats.totalPayments}</p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-lg font-semibold">Completion Rate</h2>
            <p className="text-3xl font-bold mt-2">78%</p>
          </div>
        </div>

        <div className="bg-white p-6 rounded shadow">
          <RevenueChart />
        </div>
      </div>
    </AdminLayout>
  );
}

export default Reports;