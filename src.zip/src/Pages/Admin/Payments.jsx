import { useState, useEffect } from "react";
import AdminLayout from "./AdminLayout";

function Payments() {

    const [payments, setPayments] = useState([]);

    useEffect(() => {

        fetch("http://localhost:8080/api/admin/payments")
            .then(res => res.json())
            .then(data => setPayments(data))
            .catch(err => console.log(err));

    }, []);

    const getStatusClass = (status) => {
        switch (status) {
            case "Paid":
                return "text-green-600 font-semibold";
            case "Refund Requested":
                return "text-orange-500 font-semibold";
            default:
                return "text-gray-600 font-semibold";
        }
    };

    return (
        <AdminLayout>

            <div className="flex flex-col space-y-8">

                <h1 className="text-3xl font-bold">Payments / Transactions</h1>

                <div className="bg-white shadow rounded-lg overflow-x-auto">

                    <table className="w-full text-left min-w-max">

                        <thead className="bg-gray-200">
                            <tr>
                                <th className="p-4">User ID</th>
                                <th className="p-4">Course ID</th>
                                <th className="p-4">Amount</th>
                                <th className="p-4">Status</th>
                            </tr>
                        </thead>

                        <tbody>

                            {payments.map((pay) => (

                                <tr key={pay.id} className="border-b hover:bg-gray-50">

                                    <td className="p-4">{pay.userId}</td>
                                    <td className="p-4">{pay.courseId}</td>
                                    <td className="p-4">₹{pay.amount}</td>

                                    <td className={`p-4 ${getStatusClass(pay.status)}`}>
                                        {pay.status}
                                    </td>

                                </tr>

                            ))}

                        </tbody>

                    </table>

                </div>

            </div>

        </AdminLayout>
    );
}

export default Payments;