import { useState } from "react";
import { useNavigate } from "react-router-dom";

function AdminLogin() {

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const navigate = useNavigate();

    const handleLogin = (e) => {
        e.preventDefault();

        if (email === "admin@gmail.com" && password === "admin123") {

            localStorage.setItem("admin", "true");
            navigate("/admin/dashboard");

        } else {

            alert("Invalid Admin Login");

        }
    };

    return (

        <div className="flex justify-center items-center min-h-screen bg-gray-100">

            <form onSubmit={handleLogin} className="bg-white p-8 rounded shadow w-80">

                <h2 className="text-2xl font-bold mb-4 text-center">
                    Admin Login
                </h2>

                <input
                    type="email"
                    placeholder="Admin Email"
                    className="w-full border p-2 mb-4 rounded"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                />

                <input
                    type="password"
                    placeholder="Password"
                    className="w-full border p-2 mb-4 rounded"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                />

                <button className="w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700">
                    Login
                </button>

            </form>

        </div>

    );
}

export default AdminLogin;