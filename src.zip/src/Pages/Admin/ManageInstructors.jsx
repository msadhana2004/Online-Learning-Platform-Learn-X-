import React, { useState, useEffect } from "react";
import AdminLayout from "./AdminLayout";

function ManageInstructors() {

    const [instructors, setInstructors] = useState([]);

    const [newInstructor, setNewInstructor] = useState({
        name: "",
        email: "",
        course: "",
        quality: "Good"
    });

    useEffect(() => {

        fetch("http://localhost:8080/api/admin/instructors")
            .then(res => res.json())
            .then(data => setInstructors(data))

    }, [])


    const handleChange = (e) => {
        setNewInstructor({
            ...newInstructor,
            [e.target.name]: e.target.value
        });
    };


    const addInstructor = async (e) => {

        e.preventDefault();

        const res = await fetch("http://localhost:8080/api/admin/instructors", {

            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(newInstructor)

        });

        const data = await res.json();

        setInstructors([...instructors, data]);

        setNewInstructor({
            name: "",
            email: "",
            course: "",
            quality: "Good"
        });

    };


    const deleteInstructor = async (id) => {

        await fetch(`http://localhost:8080/api/admin/instructors/${id}`, {
            method: "DELETE"
        });

        setInstructors(instructors.filter(i => i.id !== id));

    };


    return (

        <AdminLayout>

            <div className="flex flex-col space-y-8">

                <h1 className="text-3xl font-bold">Instructor Management</h1>


                {/* ADD FORM */}

                <form onSubmit={addInstructor} className="bg-white p-6 rounded shadow max-w-2xl">

                    <div className="grid md:grid-cols-2 gap-4 mb-4">

                        <input
                            type="text"
                            name="name"
                            placeholder="Instructor Name"
                            value={newInstructor.name}
                            onChange={handleChange}
                            className="border p-3 rounded"
                            required
                        />

                        <input
                            type="email"
                            name="email"
                            placeholder="Instructor Email"
                            value={newInstructor.email}
                            onChange={handleChange}
                            className="border p-3 rounded"
                            required
                        />

                        <input
                            type="text"
                            name="course"
                            placeholder="Course"
                            value={newInstructor.course}
                            onChange={handleChange}
                            className="border p-3 rounded"
                            required
                        />

                        <select
                            name="quality"
                            value={newInstructor.quality}
                            onChange={handleChange}
                            className="border p-3 rounded"
                        >

                            <option value="Excellent">Excellent</option>
                            <option value="Good">Good</option>
                            <option value="Average">Average</option>

                        </select>

                    </div>

                    <button className="bg-blue-600 text-white px-6 py-2 rounded">
                        Add Instructor
                    </button>

                </form>


                {/* TABLE */}

                <div className="bg-white rounded shadow overflow-x-auto">

                    <table className="w-full text-left">

                        <thead className="bg-gray-200">

                            <tr>

                                <th className="p-4">Name</th>
                                <th className="p-4">Email</th>
                                <th className="p-4">Course</th>
                                <th className="p-4">Quality</th>
                                <th className="p-4">Action</th>

                            </tr>

                        </thead>

                        <tbody>

                            {instructors.map((inst) => (

                                <tr key={inst.id} className="border-b">

                                    <td className="p-4">{inst.name}</td>
                                    <td className="p-4">{inst.email}</td>
                                    <td className="p-4">{inst.course}</td>
                                    <td className="p-4">{inst.quality}</td>

                                    <td className="p-4">

                                        <button
                                            onClick={() => deleteInstructor(inst.id)}
                                            className="bg-red-600 text-white px-3 py-1 rounded"
                                        >
                                            Delete
                                        </button>

                                    </td>

                                </tr>

                            ))}

                        </tbody>

                    </table>

                </div>

            </div>

        </AdminLayout>

    );
}

export default ManageInstructors;