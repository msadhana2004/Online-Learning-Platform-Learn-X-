import { Link } from "react-router-dom";
import Navbar from "../../Components/Navbar";
import Footer from "../../Components/Footer";
import Sidebar from "../../Components/Sidebar";

function AdminLayout({ children }) {
    return (
        <div className="min-h-screen flex flex-col">

            <Navbar />

            <div className="flex flex-1 bg-gray-100">

                <Sidebar className="w-64 bg-[#1E3A8A] text-white min-h-screen p-6 flex flex-col">
                    <h2 className="text-2xl font-bold mb-6">Admin Panel</h2>

                    <nav className="flex flex-col space-y-3">
                        <Link to="/admin" className="hover:text-orange-400">Dashboard</Link>
                        <Link to="/admin/add-course" className="hover:text-orange-400">Add Course</Link>
                        <Link to="/admin/manage-course" className="hover:text-orange-400">Manage Courses</Link>
                        <Link to="/admin/manage-instructor" className="hover:text-orange-400">Manage Instructors</Link>
                        <Link to="/admin/manage-user" className="hover:text-orange-400">Manage Users</Link>
                        <Link to="/admin/notification" className="hover:text-orange-400">Notifications</Link>
                        <Link to="/admin/payments" className="hover:text-orange-400">Payments</Link>
                        <Link to="/admin/reports" className="hover:text-orange-400">Reports</Link>
                    </nav>
                </Sidebar>

                <main className="flex-1 p-8">{children}</main>

            </div>

            <Footer />
        </div>
    );
}

export default AdminLayout;