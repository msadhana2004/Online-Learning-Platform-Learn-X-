import { useNavigate } from "react-router-dom";
import Navbar from "../Components/Navbar";
import Footer from "../Components/Footer";

function Dashboard() {
  const navigate = useNavigate();

  // My Courses Data
  const myCourses = [
    {
      id: 1,
      title: "React Mastery",
      progress: 75,
      lessons: "18/24 Lessons",
      color: "bg-blue-500",
    },
    {
      id: 2,
      title: "Spring Boot Advanced",
      progress: 50,
      lessons: "10/20 Lessons",
      color: "bg-orange-500",
    },
    {
      id: 3,
      title: "UI/UX Design Basics",
      progress: 35,
      lessons: "7/20 Lessons",
      color: "bg-black",
    },
  ];

  return (
    <>
      <Navbar />

      <section className="bg-[#F1F5F9] min-h-screen px-10 py-16">
        {/* Heading */}
        <div className="mb-10">
          <h1 className="text-3xl font-bold">Welcome Back 👋</h1>
          <p className="text-gray-500 mt-2">Continue your learning journey</p>
        </div>

        {/* My Courses Section */}
        <h2 className="text-2xl font-semibold mb-6">My Courses</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {myCourses.map((course) => (
            <div
              key={course.id}
              className={`${course.color} text-white rounded-xl p-6 shadow-lg`}
            >
              {/* Course Title */}
              <h2 className="text-xl font-semibold mb-4">{course.title}</h2>

              {/* Lesson Count */}
              <p className="text-sm mb-3">{course.lessons}</p>

              {/* Progress Bar */}
              <div className="bg-white/30 h-3 rounded mb-5">
                <div
                  className="bg-white h-3 rounded"
                  style={{ width: `${course.progress}%` }}
                ></div>
              </div>

              {/* Continue Button */}
              <button
                onClick={() => navigate(`/watch-video/${course.id}`)}
                className="bg-white text-black px-4 py-2 rounded-lg font-semibold hover:bg-gray-200 transition"
              >
                Continue Learning
              </button>
            </div>
          ))}
        </div>

        {/* Next Lessons Table */}
        <div className="bg-white mt-14 rounded-xl shadow p-6">
          <h2 className="text-xl font-semibold mb-6">My Next Lessons</h2>

          <table className="w-full text-left">
            <thead className="border-b">
              <tr>
                <th className="py-3">Lesson</th>
                <th>Teacher</th>
                <th>Duration</th>
              </tr>
            </thead>

            <tbody>
              <tr className="border-b">
                <td className="py-3">Introduction to React</td>
                <td>John David</td>
                <td>20 min</td>
              </tr>
              <tr className="border-b">
                <td className="py-3">Spring Boot APIs</td>
                <td>Alex Chen</td>
                <td>25 min</td>
              </tr>
              <tr>
                <td className="py-3">UI Color Theory</td>
                <td>Mia Roberts</td>
                <td>18 min</td>
              </tr>
            </tbody>
          </table>

          {/* Watch Course Video Button */}
          <div className="flex justify-center mt-10">
            <button
              onClick={() => navigate("/watch-video/1")}
              className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold shadow hover:bg-blue-700 transition"
            >
              Watch Course Video
            </button>
          </div>
        </div>
      </section>

      <Footer />
    </>
  );
}

export default Dashboard;