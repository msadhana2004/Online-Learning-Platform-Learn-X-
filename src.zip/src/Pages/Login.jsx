import { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import Navbar from "../Components/Navbar";
import Footer from "../Components/Footer";

function Login() {

  const [isRegister, setIsRegister] = useState(false);

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const navigate = useNavigate();
  const location = useLocation();

  const from = location.state?.from || "/courses";

  // ================= LOGIN =================
  const handleLogin = async () => {


    try {

      const res = await fetch("http://localhost:8080/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          email: email,
          password: password
        })
      });

      // backend returns JSON
      const data = await res.json();

      if (res.ok) {

        // save token
        localStorage.setItem("token", data.token);

        // save userId
        localStorage.setItem("userId", data.userId);

        // save role
        localStorage.setItem("role", data.role);

        // save email
        localStorage.setItem("email", email);

        alert("Login Successful");

        navigate(from);

      } else {

        alert(data);

      }

    } catch (error) {

      console.log(error);
      alert("Server Error");

    }


  };

  // ================= REGISTER =================
  const handleRegister = async () => {


    try {

      const res = await fetch("http://localhost:8080/api/auth/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          name: name,
          email: email,
          password: password
        })
      });

      const data = await res.json();

      if (res.ok) {

        alert("Registered Successfully");
        setIsRegister(false);

      } else {

        alert(data);

      }

    } catch (error) {

      console.log(error);
      alert("Server Error");

    }


  };

  return (
    <> <Navbar />


      <section className="flex flex-col md:flex-row min-h-screen">

        {/* LEFT IMAGE */}
        <div className="md:w-1/2 hidden md:block">
          <img
            src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f"
            alt="Learning"
            className="h-full w-full object-cover"
          />
        </div>

        {/* FORM */}
        <div className="md:w-1/2 flex justify-center items-center bg-[#F8FAFC] p-6">
          <div className="bg-white p-8 rounded-xl shadow-lg w-full max-w-md">

            <h2 className="text-3xl font-bold text-center mb-6 text-[#1E3A8A]">
              {isRegister ? "Register" : "Login"}
            </h2>

            {isRegister ? (

              <>
                <input
                  type="text"
                  placeholder="Name"
                  className="input"
                  onChange={(e) => setName(e.target.value)}
                />

                <input
                  type="email"
                  placeholder="Email"
                  className="input"
                  onChange={(e) => setEmail(e.target.value)}
                />

                <input
                  type="password"
                  placeholder="Password"
                  className="input"
                  onChange={(e) => setPassword(e.target.value)}
                />

                <button
                  onClick={handleRegister}
                  className="btn-primary"
                >
                  Register
                </button>

                <p className="text-center mt-4">
                  Already have an account?{" "}
                  <span
                    onClick={() => setIsRegister(false)}
                    className="text-blue-600 cursor-pointer font-semibold"
                  >
                    Login
                  </span>
                </p>
              </>

            ) : (

              <>
                <input
                  type="email"
                  placeholder="Email"
                  className="input"
                  onChange={(e) => setEmail(e.target.value)}
                />

                <input
                  type="password"
                  placeholder="Password"
                  className="input"
                  onChange={(e) => setPassword(e.target.value)}
                />

                <button
                  onClick={handleLogin}
                  className="btn-primary"
                >
                  Login
                </button>

                <p className="text-center mt-4">
                  Don’t have an account?{" "}
                  <span
                    onClick={() => setIsRegister(true)}
                    className="text-blue-600 cursor-pointer font-semibold"
                  >
                    Register
                  </span>
                </p>
              </>

            )}

          </div>
        </div>

      </section>

      <Footer />
    </>


  );
}

export default Login;
