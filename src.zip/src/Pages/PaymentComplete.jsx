import { useNavigate } from "react-router-dom";
import Navbar from "../Components/Navbar";
import Footer from "../Components/Footer";

function PaymentSuccess() {

    const navigate = useNavigate();

    return (
        <>
            <Navbar />

            <section className="min-h-screen flex flex-col justify-center items-center bg-[#F8FAFC]">

                <h1 className="text-3xl font-bold text-green-600 mb-4">
                    Payment Successful ✅
                </h1>

                <p className="text-gray-600 mb-8">
                    Your course has been successfully enrolled.
                </p>

                <button
                    onClick={() => navigate("/dashboard")}
                    className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700"
                >
                    Go To Dashboard
                </button>

            </section>

            <Footer />
        </>
    );
}

export default PaymentSuccess;