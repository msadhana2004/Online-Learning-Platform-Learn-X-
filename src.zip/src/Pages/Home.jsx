import { useNavigate } from "react-router-dom";
import Navbar from "../Components/Navbar";
import Footer from "../Components/Footer";

function Home() {
  const navigate = useNavigate();

  return (
    <>
      <Navbar />

      {/* HERO SECTION */}
      <section className="relative bg-cover bg-center h-[600px] flex items-center justify-center text-white"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1523240795612-9a054b0db644')",
        }}
      >
        <div className="bg-black/50 absolute inset-0"></div>

        <div className="relative text-center px-4">
          <h1 className="text-5xl font-bold mb-4">
            Like what you are learning?
          </h1>
          <p className="mb-6 text-lg">
            Upgrade your skills with LearnX
          </p>
          <button
            onClick={() => navigate("/courses")}
            className="bg-dark-blue px-6 py-3 rounded hover:bg-teal-600"
          >
            Get Started Now
          </button>
        </div>
      </section>

      {/* FEATURES SECTION */}
      <section className="py-16 bg-gray-100">
        <div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-8 px-4">

          <div className="bg-white shadow-lg p-6 text-center">
            <h3 className="text-xl font-bold mb-3">Multimedia Classes</h3>
            <p className="text-gray-600">
              Interactive smart classes with modern learning tools.
            </p>
          </div>

          <div className="bg-white shadow-lg p-6 text-center">
            <h3 className="text-xl font-bold mb-3">Excellent Library</h3>
            <p className="text-gray-600">
              Access thousands of learning resources anytime.
            </p>
          </div>

          <div className="bg-white shadow-lg p-6 text-center">
            <h3 className="text-xl font-bold mb-3">Transport Facilities</h3>
            <p className="text-gray-600">
              Safe and secure transport for all students.
            </p>
          </div>

        </div>
      </section>

      {/* COURSES SECTION */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold mb-10 text-center">Courses</h2>

          <div className="grid md:grid-cols-3 gap-8">

            <div className="bg-white shadow-lg rounded overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1509062522246-3755977927d7"
                alt="course"
                className="h-48 w-full object-cover"
              />
              <div className="p-6">
                <h3 className="font-bold text-lg mb-2">
                  The Complete Web Design
                </h3>
                <button className="mt-4 bg-teal-500 text-white px-4 py-2 rounded hover:bg-teal-600">
                  Apply Now
                </button>
              </div>
            </div>

            <div className="bg-white shadow-lg rounded overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f"
                alt="course"
                className="h-48 w-full object-cover"
              />
              <div className="p-6">
                <h3 className="font-bold text-lg mb-2">
                  Become a SuperLearner
                </h3>
                <button className="mt-4 bg-teal-500 text-white px-4 py-2 rounded hover:bg-teal-600">
                  Apply Now
                </button>
              </div>
            </div>

            <div className="bg-white shadow-lg rounded overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1513258496099-48168024aec0"
                alt="course"
                className="h-48 w-full object-cover"
              />
              <div className="p-6">
                <h3 className="font-bold text-lg mb-2">
                  NLP Practitioner Certification
                </h3>
                <button className="mt-4 bg-teal-500 text-white px-4 py-2 rounded hover:bg-teal-600">
                  Apply Now
                </button>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* ABOUT SECTION */}
      <section className="py-16 bg-gray-100">
        <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-10 px-4 items-center">

          <img
            src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d"
            alt="about"
            className="rounded shadow-lg"
          />

          <div>
            <h2 className="text-3xl font-bold mb-4">About LearnX</h2>
            <p className="text-gray-600 mb-6">
              Our mission is to provide world-class education to students
              worldwide with modern tools and expert instructors.
            </p>
            <button className="bg-teal-500 text-white px-6 py-3 rounded hover:bg-teal-600">
              Read More
            </button>
          </div>

        </div>
      </section>

      <Footer />
    </>
  );
}

export default Home;