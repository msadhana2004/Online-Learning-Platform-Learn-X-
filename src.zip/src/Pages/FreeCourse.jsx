import React, { useEffect, useState } from "react";
import Navbar from "../Components/Navbar";
import Footer from "../Components/Footer";
import { useNavigate } from "react-router-dom";

function FreeCourse() {
    const navigate = useNavigate();
    const [courses, setCourses] = useState([]);

    // 🔄 Fetch free courses from backend
    useEffect(() => {
        fetch("http://localhost:8080/api/courses") // all courses
            .then(res => res.json())
            .then(data => {
                // Filter only free courses (price === 0)
                const freeCourses = data.filter(c => c.price === 0);
                setCourses(freeCourses);
            })
            .catch(err => console.error(err));
    }, []);

    // 📂 Get unique categories
    const categories = [...new Set(courses.map(c => c.category))];

    return (
        <>
            <Navbar />

            <section className="py-20 bg-gray-50 min-h-screen px-8">

                <h1 className="text-4xl font-bold text-center mb-16 text-blue-900">
                    Free Courses
                </h1>

                {categories.map((category, index) => (

                    <div key={index} className="mb-16">

                        <h2 className="text-2xl font-bold mb-8 text-blue-800">
                            {category}
                        </h2>

                        <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">

                            {courses
                                .filter(c => c.category === category)
                                .map(course => (

                                    <div
                                        key={course.id}
                                        className="bg-white rounded-xl shadow-md hover:shadow-2xl transition duration-300 overflow-hidden"
                                    >

                                        {/* Course Image */}
                                        <img
                                            src={course.image}
                                            alt={course.title}
                                            className="h-40 w-full object-cover"
                                            onError={(e) => {
                                                e.target.src =
                                                    "https://via.placeholder.com/400x250?text=Course+Image";
                                            }}
                                        />

                                        <div className="p-5">

                                            <h3 className="text-lg font-semibold mb-2">
                                                {course.title}
                                            </h3>

                                            <p className="text-gray-600 text-sm mb-2">
                                                Instructor: {course.instructor}
                                            </p>

                                            <p className="text-green-600 font-bold mb-4">
                                                FREE
                                            </p>

                                            {/* View Details */}
                                            <button
                                                onClick={() => navigate(`/freecourse/${course.id}`)}
                                                className="bg-blue-900 text-white px-4 py-2 rounded w-full hover:bg-blue-700 transition"
                                            >
                                                View Details
                                            </button>

                                        </div>

                                    </div>

                                ))}

                        </div>

                    </div>

                ))}

            </section>

            <Footer />
        </>
    );
}

export default FreeCourse;