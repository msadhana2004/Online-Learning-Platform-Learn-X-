import { useParams, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import Navbar from "../Components/Navbar";
import Footer from "../Components/Footer";

function WatchVideo() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [course, setCourse] = useState(null);
  const [loading, setLoading] = useState(true);
  const [videoCompleted, setVideoCompleted] = useState(false);
  const [completed, setCompleted] = useState(false);

  // Login check
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/login");
    }
  }, [navigate]);

  // Fetch course from backend
  useEffect(() => {
    const fetchCourse = async () => {
      const token = localStorage.getItem("token");
      try {
        const response = await fetch(`http://localhost:8080/api/courses/${id}`, {
          headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + token,
          },
        });
        if (!response.ok) throw new Error("Course not found");
        const data = await response.json();
        setCourse(data);
      } catch (error) {
        console.error(error);
        setCourse(null);
      } finally {
        setLoading(false);
      }
    };

    fetchCourse();
  }, [id]);

  // 30 sec watch timer
  useEffect(() => {
    const timer = setTimeout(() => setVideoCompleted(true), 30000);
    return () => clearTimeout(timer);
  }, []);

  // Certificate generation
  const handleCertificate = async () => {
    const token = localStorage.getItem("token");
    const userId = localStorage.getItem("userId");

    try {
      const response = await fetch("http://localhost:8080/api/certificate/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer " + token,
        },
        body: JSON.stringify({
          userId: Number(userId),
          courseId: Number(id),
        }),
      });

      if (!response.ok) throw new Error("Failed to generate certificate");

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.href = url;
      a.download = "certificate.pdf";
      a.click();
    } catch (error) {
      console.error(error);
      alert("Certificate generation failed");
    }
  };

  if (loading) {
    return (
      <>
        <Navbar />
        <h1 className="text-center mt-20 text-gray-600 text-2xl">Loading Course...</h1>
        <Footer />
      </>
    );
  }

  if (!course) {
    return (
      <>
        <Navbar />
        <h1 className="text-center mt-20 text-red-600 text-2xl">Course Not Found</h1>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Navbar />
      <section className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-10">
        <h1 className="text-3xl font-bold mb-6">{course.title} Course Video</h1>

        <div className="w-full max-w-4xl">
          <iframe
            width="100%"
            height="500"
            src={course.video}
            title="Course Video"
            frameBorder="0"
            allowFullScreen
            className="rounded-lg shadow-lg"
          ></iframe>
        </div>

        {!videoCompleted && (
          <p className="mt-6 text-gray-600 font-medium">
            Please watch the video for 30 seconds to unlock completion button...
          </p>
        )}

        {videoCompleted && !completed && (
          <button
            onClick={() => setCompleted(true)}
            className="mt-6 bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700"
          >
            I Have Completed Watching
          </button>
        )}

        {completed && (
          <button
            onClick={handleCertificate}
            className="mt-6 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700"
          >
            Generate Certificate
          </button>
        )}
      </section>
      <Footer />
    </>
  );
}

export default WatchVideo;