import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../Components/Navbar";
import Footer from "../Components/Footer";

function MyCourses() {

    const [enrollments, setEnrollments] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {


        const token = localStorage.getItem("token");
        const userId = localStorage.getItem("userId");

        if (!token) {
            alert("Please login first");
            navigate("/login");
            return;
        }

        fetch(`http://localhost:8080/api/enroll/user/${userId}`, {
            method: "GET",
            headers: {
                "Authorization": "Bearer " + token
            }
        })
            .then(res => {
                if (!res.ok) {
                    throw new Error("Unauthorized");
                }
                return res.json();
            })
            .then(data => {
                setEnrollments(data);
            })
            .catch(err => {
                console.log(err);
                alert("Unable to load enrolled courses");
            });


    }, [navigate]);

    return (
        <> <Navbar />


            < section className="min-h-screen bg-gray-100 py-16 px-6" >

                <h1 className="text-3xl font-bold mb-10 text-center">
                    My Courses
                </h1>

                {
                    enrollments.length === 0 ? (

                        <p className="text-center text-gray-600">
                            You have not enrolled in any courses yet.
                        </p>

                    ) : (

                        <div className="grid md:grid-cols-3 gap-8">

                            {enrollments.map((enroll) => (

                                <div
                                    key={enroll.id}
                                    className="bg-white shadow-lg rounded-xl p-6"
                                >

                                    <h2 className="text-xl font-semibold mb-3">
                                        Course ID: {enroll.courseId}
                                    </h2>

                                    <p className="text-gray-600 mb-4">
                                        Status: {enroll.status}
                                    </p>

                                    <button
                                        onClick={() => navigate(`/watch-video/${enroll.courseId}`)}
                                        className="bg-blue-600 text-white px-4 py-2 rounded-lg mr-3"
                                    >
                                        Watch Course
                                    </button>

                                    <button
                                        onClick={() => navigate("/certificate")}
                                        className="bg-green-600 text-white px-4 py-2 rounded-lg"
                                    >
                                        Certificate
                                    </button>

                                </div>

                            ))}

                        </div>

                    )
                }

            </section >

            <Footer />
        </>


    );
}

export default MyCourses;
