import Navbar from "../Components/Navbar";
import Footer from "../Components/Footer";
import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";

function Courses() {

  const navigate = useNavigate();
  const [courses, setCourses] = useState([]);

  // login check
  useEffect(() => {

    const token = localStorage.getItem("token");

    if (!token) {
      navigate("/login");
    }

  }, [navigate]);

  // fetch courses
  useEffect(() => {

    fetch("http://localhost:8080/api/courses", {
      headers: {
        "Authorization": "Bearer " + localStorage.getItem("token")
      }
    })
      .then(res => res.json())
      .then(data => setCourses(data))

  }, [])

  const handleCourseClick = (id) => {
    navigate(`/courses/${id}`);
  }

  return (
    <>
      <Navbar />

      <section className="py-20 bg-[#F8FAFC] min-h-screen">

        <h1 className="text-4xl font-bold text-center mb-12">
          All Courses
        </h1>

        <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8 px-6 md:px-16">

          {courses.map((course) => (

            <div key={course.id}
              className="bg-white rounded-xl shadow-md hover:shadow-xl">

              <img
                src={course.image}
                alt={course.title}
                className="h-48 w-full object-cover" />

              <div className="p-6">

                <h2 className="text-xl font-semibold mb-2">
                  {course.title}
                </h2>

                <p>Instructor: {course.instructor}</p>

                <p className="font-bold text-blue-600">
                  {course.price === 0 ? "Free" : `₹${course.price}`}
                </p>

                <button
                  onClick={() => handleCourseClick(course.id)}
                  className="bg-[#1E3A8A] text-white px-4 py-2 rounded-lg w-full">

                  {course.price === 0 ? "Enroll Now" : "Buy Now"}

                </button>

              </div>

            </div>

          ))}

        </div>

      </section>

      <Footer />
    </>
  );
}

export default Courses;