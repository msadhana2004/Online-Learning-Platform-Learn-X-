import { useParams, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import Navbar from "../Components/Navbar";
import Footer from "../Components/Footer";

function FreeCourseDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [course, setCourse] = useState(null);

  // 🔒 Login check
  useEffect(() => {
    const isLoggedIn = localStorage.getItem("username");
    if (!isLoggedIn) navigate("/login");
  }, [navigate]);

  // 🔎 Fetch course from backend
  useEffect(() => {
    fetch(`http://localhost:8080/api/courses/${id}`)
      .then((res) => res.json())
      .then((data) => setCourse(data))
      .catch((err) => console.error(err));
  }, [id]);

  if (!course) {
    return (
      <>
        <Navbar />
        <h1 className="text-center mt-20 text-2xl font-bold text-red-600">
          Course Not Found
        </h1>
        <Footer />
      </>
    );
  }

  const handleEnroll = () => {
    navigate(`/watch-video/${course.id}`);
  };

  return (
    <>
      <Navbar />
      <section className="bg-[#F8FAFC] min-h-screen">
        {/* Hero Section */}
        <div className="bg-[#1E3A8A] text-white py-16 px-6 md:px-20">
          <h1 className="text-4xl font-bold mb-4">{course.title}</h1>
          <p className="text-lg max-w-3xl mb-6">{course.about}</p>
          <p className="mb-2">
            Instructor: <span className="font-semibold">{course.instructor}</span>
          </p>
          <p className="mb-2">⭐ {course.rating} ({course.reviews} reviews)</p>
          <p className="mb-4">{course.enrolled} already enrolled</p>
          <button
            onClick={handleEnroll}
            className="bg-[#F97316] px-6 py-3 rounded-lg font-semibold hover:bg-orange-600 transition"
          >
            Start Learning
          </button>
        </div>

        {/* About, Skills, Tools */}
        <div className="py-16 px-6 md:px-20">
          <h2 className="text-2xl font-bold mb-4">About this Course</h2>
          <p className="text-gray-700 leading-relaxed mb-10">{course.about}</p>

          {course.skills && (
            <>
              <h2 className="text-2xl font-bold mb-4">Skills You'll Gain</h2>
              <div className="grid md:grid-cols-3 gap-4 mb-10">
                {course.skills.map((skill, i) => (
                  <div key={i} className="bg-white shadow-md p-4 rounded-lg text-center">{skill}</div>
                ))}
              </div>
            </>
          )}

          {course.tools && (
            <>
              <h2 className="text-2xl font-bold mb-4">Tools You'll Learn</h2>
              <div className="flex flex-wrap gap-4 mb-10">
                {course.tools.map((tool, i) => (
                  <span key={i} className="bg-blue-100 text-blue-700 px-4 py-2 rounded-full text-sm">{tool}</span>
                ))}
              </div>
            </>
          )}

          <h2 className="text-2xl font-bold mb-4">Course Details</h2>
          <div className="bg-white shadow-md p-6 rounded-lg space-y-2 mb-10">
            {course.level && <p>📌 Level: {course.level}</p>}
            {course.duration && <p>⏳ Duration: {course.duration}</p>}
            {course.language && <p>🌍 Language: {course.language}</p>}
            <p>🎓 Certificate Available</p>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
}

export default FreeCourseDetails;