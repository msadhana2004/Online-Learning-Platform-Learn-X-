import { useState } from "react";
import { Link } from "react-router-dom";
import { Bars3Icon, XMarkIcon } from "@heroicons/react/24/outline";

export default function Sidebar() {
  const [open, setOpen] = useState(false);

  const links = [
    { name: "Dashboard", to: "/admin" },
    { name: "Add Course", to: "/admin/add-course" },
    { name: "Manage Courses", to: "/admin/manage-course" },
    { name: "Manage Instructors", to: "/admin/manage-instructor" },
    { name: "Manage Users", to: "/admin/manage-user" },
    { name: "Notifications", to: "/admin/notification" },
    { name: "Payments", to: "/admin/payments" },
    { name: "Reports", to: "/admin/reports" },
  ];

  return (
    <>
      {/* Mobile Header */}
      <div className="md:hidden flex items-center justify-between p-4 bg-[#1E3A8A] text-white">
        <h2 className="text-lg font-bold">Admin Panel</h2>

        <button onClick={() => setOpen(!open)}>
          {open ? (
            <XMarkIcon className="w-6 h-6" />
          ) : (
            <Bars3Icon className="w-6 h-6" />
          )}
        </button>
      </div>

      {/* Sidebar */}
      <aside
        className={`bg-[#1E3A8A] text-white w-64 min-h-screen p-6 flex flex-col space-y-4
        ${open ? "block" : "hidden md:flex"}`}
      >
        <h2 className="text-2xl font-bold mb-6 hidden md:block">
          Admin Panel
        </h2>

        {links.map((link) => (
          <Link
            key={link.name}
            to={link.to}
            className="hover:text-orange-400 transition duration-200"
            onClick={() => setOpen(false)}
          >
            {link.name}
          </Link>
        ))}
      </aside>
    </>
  );
}