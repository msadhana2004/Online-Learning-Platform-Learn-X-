import { Link, useNavigate } from "react-router-dom";
// import { Link } from "react-router-dom";

{/* <Link to="/dashboard">Dashboard</Link> */}
function Navbar() {
  const navigate = useNavigate();

  const handleCoursesClick = () => {
    const isLoggedIn = localStorage.getItem("user");
    if (isLoggedIn) navigate("/courses");
    else navigate("/login");
  };

  const handleFreeCoursesClick = () => {
    const isLoggedIn = localStorage.getItem("user");
    if (isLoggedIn) navigate("/freecourse");
    else navigate("/login");
  };

  return (
    <nav className="bg-[#1E3A8A] text-white px-10 py-4 flex justify-between items-center shadow-md">
      <h1 className="text-2xl font-bold cursor-pointer">LearnX</h1>

      <div className="space-x-6 font-medium">
        <Link to="/" className="hover:text-orange-400">Home</Link>
        <button onClick={handleCoursesClick} className="hover:text-orange-400">
          Courses
        </button>
        <button onClick={handleFreeCoursesClick} className="hover:text-orange-400">
          Free Courses
        </button>
        <Link to="/login" className="bg-[#F97316] px-4 py-2 rounded hover:bg-orange-600">
          Login
        </Link>
      </div>
    </nav>
  );
}

export default Navbar;