function Footer() {
    return (
        <footer className="relative mt-16 text-white overflow-hidden">
            {/* Background */}
            <div
                className="absolute inset-0 bg-cover bg-center"
                style={{ backgroundImage: "url('https://images.unsplash.com/photo-1522202176988-66273c2fd55f')" }}
            ></div>

            {/* Overlay */}
            <div className="absolute inset-0 bg-[#1E3A8A]/80"></div>

            <div className="relative z-10">
                <div className="max-w-7xl mx-auto px-6 py-12 grid md:grid-cols-4 gap-10">
                    {/* Logo */}
                    <div className="space-y-4">
                        <link
                            href="https://fonts.googleapis.com/css2?family=Playball&family=Poppins:wght@400;600&display=swap"
                            rel="stylesheet"
                        />
                        <h2
                            className="text-7xl font-bold tracking-wide text-orange-400 hover:scale-110 hover:text-yellow-300 transition duration-500"
                            style={{ fontFamily: "'Playball', cursive" }}
                        >
                            Learn<span className="text-white">x</span>
                        </h2>
                        <p className="text-gray-300 text-sm" style={{ fontFamily: "'Poppins', sans-serif" }}>
                            Learnx is a modern learning platform providing quality courses and resources.
                        </p>
                    </div>

                    {/* Navigation */}
                    <div>
                        <h3 className="text-lg font-semibold mb-4 border-b-2 border-orange-400 inline-block">Navigation</h3>
                        <ul className="space-y-2 text-gray-300">
                            <li className="hover:text-orange-400 hover:translate-x-2 transition duration-300 cursor-pointer">Home</li>
                            <li className="hover:text-orange-400 hover:translate-x-2 transition duration-300 cursor-pointer">Courses</li>
                            <li className="hover:text-orange-400 hover:translate-x-2 transition duration-300 cursor-pointer">About</li>
                            <li className="hover:text-orange-400 hover:translate-x-2 transition duration-300 cursor-pointer">Contact</li>
                        </ul>
                    </div>

                    {/* Support */}
                    <div>
                        <h3 className="text-lg font-semibold mb-4 border-b-2 border-orange-400 inline-block">Support</h3>
                        <ul className="space-y-2 text-gray-300">
                            <li className="hover:text-orange-400 hover:translate-x-2 transition duration-300 cursor-pointer">Help Center</li>
                            <li className="hover:text-orange-400 hover:translate-x-2 transition duration-300 cursor-pointer">Privacy Policy</li>
                            <li className="hover:text-orange-400 hover:translate-x-2 transition duration-300 cursor-pointer">Terms & Conditions</li>
                        </ul>
                    </div>

                    {/* Contact */}
                    <div>
                        <h3 className="text-lg font-semibold mb-4 border-b-2 border-orange-400 inline-block">Contact</h3>
                        <p className="text-gray-300 text-sm">📍 Chennai, India</p>
                        <p className="text-gray-300 text-sm">📞 +91 98765 43210</p>
                        <p className="text-gray-300 text-sm">✉ support@learnx.com</p>
                    </div>
                </div>

                {/* Bottom */}
                <div className="bg-[#162C6B] text-center py-4 text-gray-300 text-sm">
                    © 2026 Learnx. All Rights Reserved.
                </div>
            </div>
        </footer>
    );
}

export default Footer;